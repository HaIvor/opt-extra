
modem_ip = 'localhost' # '192.168.42.195'
portnumber = 1101 # Change to 1100 if not using simulation
modem_name = str(191) # modem_ip[:3] # Use the modem_ip if not simulating
# domain_id = 1 # For ROS 2. Not necessarry if each ROS 2 system is on its own machine.